<!DOCTYPE html>
<html>
<head>
	<title>Game Studio</title>
	<link rel="stylesheet" type="text/css" href="../styles/ResetCSS.css" />
	<link rel="stylesheet" type="text/css" href="CodeMirror/lib/codemirror.css">
	<script src="CodeMirror/lib/codemirror.js"></script>
	<script src="CodeMirror/modes/javascript.js" type="text/javascript" ></script>
	<script src="CodeMirror/modes/css.js" type="text/javascript" ></script>
	<script src="CodeMirror/modes/php.js" type="text/javascript" ></script>
	<script src="CodeMirror/modes/htmlmixed.js" type="text/javascript" ></script>
	<meta charset="utf-8" />
<style type="text/css" >
	html, body {
	height: 100%;
	width: 100%;
	font-family: sans-serif;
	}
	#canvas {
	border: 1px solid #000;
	display: inline-block;
	height: 400px;
	background-image: url(alpha.gif);
	background-repeat: repeat;
	user-select: none;	
	-o-user-select: none;	
	-moz-user-select: none;	
	-webkit-user-select: none;
	}
	canvas {
	user-select: none;	
	-o-user-select: none;	
	-moz-user-select: none;	
	-webkit-user-select: none;	
	}
	#bottom-bar {
	background-color: #777;
	color: #FFF;
	padding: 4px 0px 2px 4px;
	border-top: 2px solid #FFF;
	width: 100%;
	}
	#screen {
	border: 3px solid #AAA;
	border-top-width: 0px;
	border-left-width: 0px;
	display: inline-block;
	}
	#top-bar {
	background-color:#777;
	color:#FFF;
	padding: 2px 4px 3px 0px;
	text-align: right;
	width: 100%;
	}
	#selected-tab {
	background-color: #24F;
	color: #FFF;
	font-weight: bold;
	user-select: none;	
	-o-user-select: none;	
	-moz-user-select: none;	
	-webkit-user-select: none;
	}
	#object-name {
	float: right;
	padding-right: 5px;
	}
	#objects {
	background-color:#AAA;
	}
	#left-pane {
	float:left;
	display: inline-block;
	height: 100%;
	}
	#scene-number {
	float: left;
	padding-left: 7px;
	padding-top: 5px;
	color: #0F0;
	font-family: monospace;
	font-size: 155%;
	}
	#tabs {
	margin-top: 4px;
	display: inline-block;
	user-select: none;	
	-o-user-select: none;	
	-moz-user-select: none;	
	-webkit-user-select: none;
	}
	.tab {
	display: inline-block;
	padding-left: 2px;
	padding-right: 4px;
	border: 1px solid #000;
	border-bottom-width: 0px;
	background-color: #EE6;
	user-select: none;	
	-o-user-select: none;	
	-moz-user-select: none;	
	-webkit-user-select: none;
	}
	#right-pane {
	float: right;
	width: 59%;
	height: 100%;
	}
	#left-pane {
	display: inline-block;
	height: 100%;
	width: 41%;	
	}
	#coords {
	font-family: monospace;
	font-size: 115%;
	}
	#x-coord {
	color: #FF0;	
	}
	#y-coord {
	color: #5FF;	
	}
	#tab-contents {
	background-color: #EE6;
	border-left: 1px solid #111;
	border-bottom: 1px solid #111;
	padding: 0.5%;
	height: 94%;
	}
	#objects {
	background-color: #CCC;
	padding: 0.5%;
	height: 23%;
	width: 95.5%;
	overflow-y: scroll;
	overflow-x: auto;
	}
	.code {
	width: 99%;
	height: 100%;
	}
	.CodeMirror {
   		border: 1px solid #eee;
 		height: 99%;
 		width: 99%;
	}
	.popup-window {
		border: 1px solid #000;
		position: absolute;
		top: 0px;
		left: 0px;
		display: inline-block;
		background-color: #EEE;
	}
	.popup-title {
		text-align: left;
		width: 100%;
		border-bottom: 1px solid #000;
		font-weight: bold;
		background-color: #22F;
		color: #FFF;
		font-family: monospace;
		padding: 0.5%;
		user-select: none;	
		-o-user-select: none;	
		-moz-user-select: none;	
		-webkit-user-select: none;
	}
	.popup-close {
		display: inline-block;
		font-size: 11px;
		background-color: #F00;
		padding: 2px;
		float: right;
		margin-right: 0.5%;
		user-select: none;	
		-o-user-select: none;	
		-moz-user-select: none;	
		-webkit-user-select: none;
	}
</style>
</head>	
<body>

<div id="left-pane" >
<div id="screen" >
	<div id="top-bar" >
		<span id="scene-number" ><b>0</b></span>
		<button type="button" ><b>&lt;</b></button>
		<button type="button" ><b>&gt;</b></button>
		<button type="button" >Stop</button>
		<button type="button" onclick="StartGame();" >Start</button>
	</div>
	<div id="canvas" oncontextmenu="rightClickedScreen(event);" >
		<canvas id="gamecanvas" height="400px" width="400px" ></canvas>
	</div>
<div id="bottom-bar" >
	<span id="coords" ><b>X:<span id="x-coord" >0</span>&nbsp;Y:<span id="y-coord" >0</span></b></span>
	<span id="object-name" >No Selection</span>
</div>
</div>
<div id="objects" >	
<button type="button" onclick="addObject();" >Add</button>
</div>
</div>

<div id="right-pane" >
<div id="tabs" >
<div class="tab" id="selected-tab" >Game</div>
</div>
<div id="tab-contents" >
<div class="code">
<textarea id="0_code" >alert("Hello, World!");</textarea>
</div>
</div>
</div>
<script>
var Studio = {};
Studio.popUpsTotal = 0;
Studio.showingAlpha = true;
Studio.rightCanvasPopUp = new Popup(0,0,"", document.createTextNode(""), false);
var codeWindows = [];
var hiddenCodes = [];
var allCode = "";

function closePopUp(e) {
var ele = e.target;
var done = false;
while(!done && ele.tagName != undefined) {
	if(e.target.getAttribute("class") == "popup-close") {
		document.body.removeChild(ele.parentNode.parentNode);
		done = true;
	}
	else {
		ele = ele.parentNode;
	}
}
}

function Popup(x, y, title, content, notCloseable) {
this.self = this;
this.title = title;
this.x = x;
this.y = y;
this.content = content;
this.notCloseable = notCloseable;
this.visible = false;
Studio.popUpsTotal++;
this.id = "popUp_" + Studio.popUpsTotal;
Studio.popUpsTotal++;

this.hide = function() {
if(this.visible) {
document.body.removeChild(document.getElementById(this.id));
}
else {
//nope it wasn't showing 	
}
this.mouseOn = false;
this.visible = false;
};

this.onmouseout = function() { 
	this.mouseOn = false;
};

this.onmouseover = function() {
	this.mouseOn = true;
};

this.show = function() {
	if(!this.visible) {
	var d = document.createElement("div");
	d.id = this.id;
	d.setAttribute("class", "popup-window");
	d.setAttribute("style", "top: " + y + "px; left: " + x + "px; z-index: 900;");
	
	var pt = document.createElement("div");
	pt.setAttribute("class", "popup-title");
	pt.appendChild(document.createTextNode(title));
	if(!notCloseable) {
		var closeButton = document.createElement("div");
		closeButton.setAttribute("class", "popup-close");
		closeButton.appendChild(document.createTextNode("x"));
		closeButton.addEventListener("click", closePopUp);
		pt.appendChild(closeButton);
	}
	
	
	d.appendChild(pt);
	
	var contDiv = document.createElement("div");
	contDiv.setAttribute("style", "padding: 5px;");
	contDiv.appendChild(content);
	
	d.appendChild(contDiv);
	this.self.dom = d;
	d.addEventListener("mouseout", this.self.onmouseout);
	document.body.appendChild(d);
	}
	this.visible = true;
};

}

function makePrompt(title, x, y, content, notCloseable) {
	
	var d = document.createElement("div")
	d.setAttribute("class", "popup-window");
	d.setAttribute("style", "top: " + y + "px; left: " + x + "px; z-index: 900;");
	
	var pt = document.createElement("div");
	pt.setAttribute("class", "popup-title");
	pt.appendChild(document.createTextNode(title));
	if(!notCloseable) {
		var closeButton = document.createElement("div");
		closeButton.setAttribute("class", "popup-close");
		closeButton.appendChild(document.createTextNode("x"));
		closeButton.addEventListener("click", closePopUp);
		pt.appendChild(closeButton);
	}
	
	
	d.appendChild(pt);
	
	var contDiv = document.createElement("div");
	contDiv.setAttribute("style", "padding: 5px;");
	contDiv.appendChild(content);
	
	d.appendChild(contDiv);
	
	return d;
}

function Code(name, lang) {
this.name = name;
this.lang = lang;
var cspace = document.createElement("div");

}

function confirmCreate(e) {
	var type = document.getElementById("obj-type").value;
	var name = document.getElementById("obj-name").value;
	switch(type) {
	case "c":
	var o = new Code(name, "js");
	break;
	default:
	
	break;
	}
	document.body.removeChild(e.target.parentNode.parentNode.parentNode);
}

function addObject() {
	var selectCodes = "";
	var selections = [];
	var select_values = [];
	selections.push("ImageSprite", "Background", "Sound", "ImageLoadStack", "Game", "Code");
	select_values.push("ims", "bg", "s", "ils", "g", "c");
	
	var content = document.createElement("form");
	content.appendChild(document.createTextNode("Object Type:"));
	
	var s = document.createElement("select");
	s.id='obj-type';
	for(var i = 0; i < selections.length; i++) {
		var a = document.createElement("option");
		a.setAttribute("value", select_values[i]);
		a.appendChild(document.createTextNode(selections[i]));
		s.appendChild(a);
	}
	content.appendChild(s);
	content.appendChild(document.createElement("br"));
	
	var name = document.createElement("span");
	name.appendChild(document.createTextNode("Name:"));
	var inp = document.createElement("input");
	inp.setAttribute("type", "text");
	inp.id = "obj-name";
	name.appendChild(inp)
	content.appendChild(name);
	
	var b = document.createElement("button");
	b.setAttribute("type", "button");
	b.addEventListener("click", confirmCreate);
	b.appendChild(document.createTextNode("Create"));
	content.appendChild(b);

	document.body.appendChild(makePrompt("Add Object...", 300, 200, content, false));
}

function toggleAlpha() {
	if(Studio.showingAlpha) {
		Studio.showingAlpha = false;
		document.getElementById("canvas").style.backgroundImage = "none";
	}
	else {
		Studio.showingAlpha = true;
		document.getElementById("canvas").style.backgroundImage = "url(./alpha.gif)";
	}
}

window.onclick = function() {
	if(!Studio.rightCanvasPopUp.mouseOn) {
		Studio.rightCanvasPopUp.hide();
	}
};

function rightClickedScreen(e) {
	e.preventDefault();
	Studio.rightCanvasPopUp.hide();
	Studio.rightCanvasPopUp = {};
	var b = document.createElement("button");
	b.setAttribute("type", "button");
	b.addEventListener("click", toggleAlpha);
	var btext = "";
	b.appendChild(document.createTextNode("Toggle Alpha"));
	var p = new Popup(e.clientX, e.clientY, "", b, true);
	p.show();
	Studio.rightCanvasPopUp = p;
}

function StartGame() {
	
allCode = "";
for(var h = 0; h < hiddenCodes.length; h++) {
	allCode += "" + hiddenCodes[h];
}
for(var w = 0; w < codeWindows.length; w++) {
	allCode += "" + codeWindows[w].doc.getValue();
}
	
document.body.removeChild(document.getElementById("outputCode"));

var s = document.createElement("script");
s.id = "outputCode";
s.appendChild(document.createTextNode(allCode));
document.body.appendChild(s);

}

window.onload = function() {
  var code0 = CodeMirror.fromTextArea(document.getElementById("0_code"), {
    lineNumbers: true,
    mode: "javascript",
    viewportMargin: 40,
    dragDrop: false,
    cursorBlinkRate: 0,
    
  });
codeWindows.push(code0);
};


</script>
<script id="outputCode" ></script>
</body>	
</html>